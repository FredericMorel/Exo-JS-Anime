// TODO:  
// FIXME: 


/* console.log(finalListTypeAnime)

const setTypeAnime=new Set()
 finalListTypeAnime.forEach(element => {
    setTypeAnime.add(element)
 });

setTypeAnime.add('BlueRay')
console.log("original list :",finalListTypeAnime);
console.log("final list : ",setTypeAnime);

   /*  */

/*     switch (key) {
        case value:
            
            break;
    
        default:
            break;
    } */

/*     setTypeAnime.forEach(item=>{
        let htmlButtonTypeAnime=document.getElementsByClassName("btn-type-"+item)
        htmlButtonTypeAnime.addEventListener('click',event=>{
            console.log(`test dernier : ${event.target.name}`);
        })
      
    }) */ /* */